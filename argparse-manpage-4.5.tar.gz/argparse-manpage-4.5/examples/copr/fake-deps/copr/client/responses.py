class CoprResponse:
    pass
