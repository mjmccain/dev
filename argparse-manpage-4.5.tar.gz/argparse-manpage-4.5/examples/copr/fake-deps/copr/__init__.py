# Hack

class CoprClient(object):
    pass
