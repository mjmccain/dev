class Ticket:
    pass

class Connection:
    pass
