"""
argparse_manpage project
"""

__version__ = '4.5'
