"""
Compat only module.  Users should use argparse_manpage.manpage:Manpage
"""

# pylint: disable=unused-import
from argparse_manpage.manpage import Manpage
